﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC_DataAccessLayer;
using System.Configuration;
using System.Data.SqlClient;
using System.Dynamic;
using System.Data;
using System.IO;
using System.Web.UI;

namespace MyHire_Demand_Analyser.Models
{
    public class MyHire_PickList_Master
    {
        DataAccess db = new DataAccess();

        public DataTable GetMYhirePickEntity(string PickListType)
        {
            try
            {
                DataSet dtlog = new DataSet();
                dtlog = db.GetMyHirePickListMaster(PickListType);
                return dtlog.Tables[0];
            }
            catch (Exception e)
            {
                return null;
            }
        }

        public void ExportPickList(DataTable dtPicklist)
        {
            try
            {
                var grid = new System.Web.UI.WebControls.GridView();
                grid.DataSource = dtPicklist;
                grid.DataBind();
                HttpContext.Current.Response.ClearContent();
                HttpContext.Current.Response.AddHeader("content-disposition", "attachment; filename=MyHirePickList.xls");
                HttpContext.Current.Response.ContentType = "application/excel";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                grid.RenderControl(htw);
                HttpContext.Current.Response.Write(sw.ToString());
                HttpContext.Current.Response.End();
            }
            catch (Exception e)
            {
                
            }
        }  
    }
}