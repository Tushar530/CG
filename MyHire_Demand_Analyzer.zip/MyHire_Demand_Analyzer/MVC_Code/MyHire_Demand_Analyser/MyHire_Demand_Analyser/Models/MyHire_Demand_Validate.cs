﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Dynamic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using MVC_DataAccessLayer;
using System.Web.Mvc; 

namespace MyHire_Demand_Analyser.Models
{
    public class MyHire_Demand_Validate
    {
        public SelectList MYhireCountryDDL2 { get; set; }
        DataAccess db = new DataAccess();

        //-- To fill Country Dropdown list--//
        public string DD_SBU_Name { get; set; }
        public string DD_Country { get; set; }
        public SelectList MYhireCountryDDL3 { get; set; }
        //------ END -----//

        public string ErrorStatus { get; set; }
        public string SentToMyHire { get; set; }
        public string LastUpdated { get; set; }
        public string OneBusStatus { get; set; }
        public string ReceivedByMyHire { get; set; }
        public string ACKMessage { get; set; }
        public string MyHireStatus { get; set; }
        public string JobRequestID { get; set; }
        public string PositionIdGUID { get; set; }
        public string PositionId { get; set; }
        public string RequisitionId { get; set; }
        public string RequisitionStatus { get; set; }
        public string RequisitionChangeDate { get; set; }
        public string RequisitionSOCreationDate { get; set; }
        public string PositionCountry { get; set; }
        public string PositionLocationstateProvince { get; set; }
        public string PositionLocationLocation { get; set; }
        public string Division { get; set; }
        public string department { get; set; }
        public string SubBu { get; set; }
        public string PositionRoleJobTitle { get; set; }
        public string PositionRoleJobRole { get; set; }
        public string PositionTitle { get; set; }

        public string Local_Grade { get; set; }
        public string MINIMUM_GRADE { get; set; }
        public string RequisitionOriginator { get; set; }
        public string Requestor { get; set; }
        public string RequisitionCreationRctmntStrtDate { get; set; }
        public string RequisitionjobStartDate { get; set; }
        public string RequistionJobEndDate { get; set; }
        public string PositionFTE { get; set; }
        public string PrjName { get; set; }
        public string PositionFulfilmentChannel { get; set; }
        public string Currency { get; set; }
        public string CustHotSkill { get; set; }
        public string CusthotSkillbonus { get; set; }
        public string Status { get; set; }
        public string FullFillmentType { get; set; }
        public string entity { get; set; }
        public string AccountName { get; set; }
        public string HiringOffice { get; set; }
        public string HiringManager { get; set; }
        public string Supervisor { get; set; }
        public string R2D2Status { get; set; }
        public string RecruiterGGID { get; set; }
        public string ServiceLine { get; set; }
        public string Changedate { get; set; }
        //public string ONEBUS_JR_POSTED { get; set; }
        ////public string MyHireStatus { get; set; }
        //public string MyHireMessage { get; set; }
        //public string ACKDate { get; set; }

        public DataSet GetMyHireDemandDetails(DataSet ds)
        {
            DataTable dtbkg = new DataTable();
            DataRow drbkg;
            DataSet ds1 = new DataSet();
            dtbkg.TableName = "GrdASPData";
            dtbkg.Columns.Add(new DataColumn("Requisitionid", typeof(string)));
            dtbkg.Columns.Add(new DataColumn("Positionid", typeof(string)));
            
            foreach (DataRow DR in ds.Tables[0].Rows)
            {
                drbkg = dtbkg.NewRow();
                drbkg["Requisitionid"] = DR["Requistion ID"].ToString();
                drbkg["Positionid"] = DR["Position ID"].ToString();
                dtbkg.Rows.Add(drbkg);
            }
           
            if (dtbkg.Rows.Count > 0)
            {
                //DataSet inser = new DataSet();
                DataTable tbl = new DataTable();
                //inser = db.SaveASPBooking(userLogin, dtbkg);
                tbl = db.SaveAspBooking1(dtbkg);
            }
            return ds;
            throw new NotImplementedException();
        }

        public List<MyHire_Demand_Validate> GetMyHireDemandDetail1(DataSet ds)
        {
            try
            {
                int output = 0;
                DataTable dt = new DataTable();
                DataRow dr;
                DataSet dsLogData = new DataSet();
                dt.TableName = "GrdASPData";
                dt.Columns.Add(new DataColumn("Requisitionid", typeof(string)));
                dt.Columns.Add(new DataColumn("Positionid", typeof(string)));
                
                foreach (DataRow DR in ds.Tables[0].Rows)
                {
                    dr = dt.NewRow();
                    dr["Requisitionid"] = DR["Requistion ID"].ToString();
                    dr["Positionid"] = DR["Position ID"].ToString();
                    
                    dt.Rows.Add(dr);
                }
                if (dt.Rows.Count > 0)
                {
                    DataTable dtLog = new DataTable();
                    dtLog = db.GetMyHireValidData1(dt);

                    List<MyHire_Demand_Validate> abc = new List<MyHire_Demand_Validate>();

                    foreach (DataRow row in dtLog.Rows)
                    {
                        MyHire_Demand_Validate stud = new MyHire_Demand_Validate();
                        stud.ErrorStatus = row["ErrorStatus"].ToString();
                        stud.SentToMyHire = row["SentToMyHire"].ToString();
                        stud.LastUpdated = row["LastUpdated"].ToString();
                        stud.OneBusStatus = row["OneBusStatus"].ToString();
                        stud.ReceivedByMyHire = row["ReceivedByMyHire"].ToString();
                        stud.ACKMessage = row["ACKMessage"].ToString();
                        stud.MyHireStatus = row["MyHireStatus"].ToString();
                        stud.JobRequestID = row["JobRequestID"].ToString();
                        stud.PositionIdGUID = row["PositionIdGUID"].ToString();
                        stud.PositionId = row["PositionId"].ToString();
                        stud.RequisitionId = row["RequisitionId"].ToString();
                        stud.RequisitionStatus = row["RequisitionStatus"].ToString();
                        stud.RequisitionChangeDate = row["RequisitionChangeDate"].ToString();
                        stud.RequisitionSOCreationDate = row["RequisitionSOCreationDate"].ToString();
                        stud.PositionCountry = row["PositionCountry"].ToString();
                        stud.PositionLocationstateProvince = row["PositionLocationstateProvince"].ToString();
                        stud.PositionLocationLocation = row["PositionLocationLocation"].ToString();
                        stud.Division = row["Division"].ToString();
                        stud.department = row["department"].ToString();
                        stud.SubBu = row["SubBu"].ToString();
                        stud.PositionRoleJobTitle = row["PositionRoleJobTitle"].ToString();
                        stud.PositionRoleJobRole = row["PositionRoleJobRole"].ToString();
                        stud.PositionTitle = row["PositionTitle"].ToString();
                        stud.Local_Grade = row["Local_Grade"].ToString();
                        stud.MINIMUM_GRADE = row["MINIMUM_GRADE"].ToString();
                        stud.RequisitionOriginator = row["RequisitionOriginator"].ToString();
                        stud.Requestor = row["Requestor"].ToString();
                        stud.RequisitionCreationRctmntStrtDate = row["RequisitionCreationRctmntStrtDate"].ToString();
                        stud.RequisitionjobStartDate = row["RequisitionjobStartDate"].ToString();
                        stud.RequistionJobEndDate = row["RequistionJobEndDate"].ToString();
                        stud.PositionFTE = row["PositionFTE"].ToString();
                        stud.PrjName = row["PrjName"].ToString();
                        stud.PositionFulfilmentChannel = row["PositionFulfilmentChannel"].ToString();
                        stud.Currency = row["Currency"].ToString();
                        stud.CustHotSkill = row["CustHotSkill"].ToString();
                        stud.CusthotSkillbonus = row["CusthotSkillbonus"].ToString();
                        stud.Status = row["Status"].ToString();
                        stud.FullFillmentType = row["FullFillmentType"].ToString();
                        stud.entity = row["entity"].ToString();
                        stud.AccountName = row["AccountName"].ToString();
                        stud.HiringOffice = row["HiringOffice"].ToString();
                        stud.HiringManager = row["HiringManager"].ToString();
                        stud.Supervisor = row["Supervisor"].ToString();
                        stud.R2D2Status = row["R2D2Status"].ToString();
                        stud.RecruiterGGID = row["RecruiterGGID"].ToString();
                        stud.ServiceLine = row["ServiceLine"].ToString();
                        stud.Changedate = row["Changedate"].ToString();
                        //stud.ONEBUS_JR_POSTED = row["ONEBUS_JR_POSTED"].ToString();
                        //stud.MyHireMessage = row["MyHireMessage"].ToString();
                        //stud.ACKDate = row["ACKDate"].ToString();

                        abc.Add(stud);
                    }

                    return abc;
                }
                return null;
            }
            catch (Exception Ex)
            {
                return null;
            }
        }


         public List<MyHire_Demand_Validate> Search(string positionid)
        {
            try
            {
                    DataTable dtLog = new DataTable();
                    dtLog = db.GetMyHireSingleSearch_Demand(positionid);

                    List<MyHire_Demand_Validate> abc = new List<MyHire_Demand_Validate>();

                    foreach (DataRow row in dtLog.Rows)
                    {
                        MyHire_Demand_Validate stud = new MyHire_Demand_Validate();
                        stud.ErrorStatus = row["ErrorStatus"].ToString();
                        stud.SentToMyHire = row["SentToMyHire"].ToString();
                        stud.LastUpdated = row["LastUpdated"].ToString();
                        stud.OneBusStatus = row["OneBusStatus"].ToString();
                        stud.ReceivedByMyHire = row["ReceivedByMyHire"].ToString();
                        stud.ACKMessage = row["ACKMessage"].ToString();
                        stud.MyHireStatus = row["MyHireStatus"].ToString();
                        stud.JobRequestID = row["JobRequestID"].ToString();
                        stud.PositionIdGUID = row["PositionIdGUID"].ToString();
                        stud.PositionId = row["PositionId"].ToString();
                        stud.RequisitionId = row["RequisitionId"].ToString();
                        stud.RequisitionStatus = row["RequisitionStatus"].ToString();
                        stud.RequisitionChangeDate = row["RequisitionChangeDate"].ToString();
                        stud.RequisitionSOCreationDate = row["RequisitionSOCreationDate"].ToString();
                        stud.PositionCountry = row["PositionCountry"].ToString();
                        stud.PositionLocationstateProvince = row["PositionLocationstateProvince"].ToString();
                        stud.PositionLocationLocation = row["PositionLocationLocation"].ToString();
                        stud.Division = row["Division"].ToString();
                        stud.department = row["department"].ToString();
                        stud.SubBu = row["SubBu"].ToString();
                        stud.PositionRoleJobTitle = row["PositionRoleJobTitle"].ToString();
                        stud.PositionRoleJobRole = row["PositionRoleJobRole"].ToString();
                        stud.PositionTitle = row["PositionTitle"].ToString();
                        stud.Local_Grade = row["Local_Grade"].ToString();
                        stud.MINIMUM_GRADE = row["MINIMUM_GRADE"].ToString();
                        stud.RequisitionOriginator = row["RequisitionOriginator"].ToString();
                        stud.Requestor = row["Requestor"].ToString();
                        stud.RequisitionCreationRctmntStrtDate = row["RequisitionCreationRctmntStrtDate"].ToString();
                        stud.RequisitionjobStartDate = row["RequisitionjobStartDate"].ToString();
                        stud.RequistionJobEndDate = row["RequistionJobEndDate"].ToString();
                        stud.PositionFTE = row["PositionFTE"].ToString();
                        stud.PrjName = row["PrjName"].ToString();
                        stud.PositionFulfilmentChannel = row["PositionFulfilmentChannel"].ToString();
                        stud.Currency = row["Currency"].ToString();
                        stud.CustHotSkill = row["CustHotSkill"].ToString();
                        stud.CusthotSkillbonus = row["CusthotSkillbonus"].ToString();
                        stud.Status = row["Status"].ToString();
                        stud.FullFillmentType = row["FullFillmentType"].ToString();
                        stud.entity = row["entity"].ToString();
                        stud.AccountName = row["AccountName"].ToString();
                        stud.HiringOffice = row["HiringOffice"].ToString();
                        stud.HiringManager = row["HiringManager"].ToString();
                        stud.Supervisor = row["Supervisor"].ToString();
                        stud.R2D2Status = row["R2D2Status"].ToString();
                        stud.RecruiterGGID = row["RecruiterGGID"].ToString();
                        stud.ServiceLine = row["ServiceLine"].ToString();
                        stud.Changedate = row["Changedate"].ToString();
                        //stud.ONEBUS_JR_POSTED = row["ONEBUS_JR_POSTED"].ToString();
                        //stud.MyHireMessage = row["MyHireMessage"].ToString();
                        //stud.ACKDate = row["ACKDate"].ToString();

                        abc.Add(stud);
                    }

                   
                return abc;
            }
            catch (Exception Ex)
            {
                return null;
            }
        }

         public List<MyHire_Demand_Validate> CountryDropDown(string CountryCode)
         {
             try
             {
                 DataTable dtLog = new DataTable();
                 dtLog = db.GetMyCountryDropdown(CountryCode);
                 List<MyHire_Demand_Validate> abc = new List<MyHire_Demand_Validate>();
                 foreach (DataRow row in dtLog.Rows)
                 {
                     MyHire_Demand_Validate stud = new MyHire_Demand_Validate();
                     stud.DD_Country = row["DD_Country"].ToString();
                     abc.Add(stud);
                 }
                 return abc;
             }
             catch (Exception Ex)
             {
                 return null;
             }
         }

         public IEnumerable<MyHire_Demand_Validate> CountryDropDown1(string CountryCode)
         {
             try
             {
                 DataTable dtLog = new DataTable();
                 dtLog = db.GetMyCountryDropdown(CountryCode);
                 List<MyHire_Demand_Validate> abc = new List<MyHire_Demand_Validate>();
                 foreach (DataRow row in dtLog.Rows)
                 {
                     MyHire_Demand_Validate stud = new MyHire_Demand_Validate();
                     stud.DD_Country = row["DD_Country"].ToString();
                     abc.Add(stud);
                 }
                 return abc;
             }
             catch (Exception Ex)
             {
                 return null;
             }
         }
          
    }
}