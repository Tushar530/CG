﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Dynamic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using MVC_DataAccessLayer;
using System.Data.OleDb;
using MyHire_Demand_Analyser.Models;
using System.Web.Mvc;


namespace MyHire_Demand_Analyser.MyHireDemand_ViewModel
{
    public class MyHireDemand_Validation
    {
        DataAccess db = new DataAccess();

        public string DD_SBU_Name { get; set; }
        public string DD_Country { get; set; }

        public IEnumerable<MyHire_Demand_Validate> MYhireValid { get; set; }
        public IEnumerable<MyHire_Demand_Validate> MYhireSingleSearch { get; set; }

        public IEnumerable<MyHire_Demand_Validate> MYhireCountryDDL { get; set; }


        public SelectList MYhireCountryDDL1 { get; set; }

        public List<MyHireDemand_Validation> CountryDropDown1(string CountryCode)
        {
            try
            {
                DataTable dtLog = new DataTable();
                dtLog = db.GetMyCountryDropdown(CountryCode);
                List<MyHireDemand_Validation> abc = new List<MyHireDemand_Validation>();
                foreach (DataRow row in dtLog.Rows)
                {
                    MyHireDemand_Validation stud = new MyHireDemand_Validation();
                    stud.DD_Country = row["DD_Country"].ToString();
                    abc.Add(stud);
                }
                return abc;
            }
            catch (Exception Ex)
            {
                return null;
            }
        }


        public List<MyHireDemand_Validation> SBUDropDown(string CountryCode)
        {
            try
            {
                DataTable dtLog = new DataTable();
                dtLog = db.GetMyCountryDropdown(CountryCode);
                List<MyHireDemand_Validation> abc = new List<MyHireDemand_Validation>();
                foreach (DataRow row in dtLog.Rows)
                {
                    MyHireDemand_Validation stud = new MyHireDemand_Validation();
                    stud.DD_SBU_Name = row["DD_SBU_Name"].ToString();
                    abc.Add(stud);
                }
                return abc;
            }
            catch (Exception Ex)
            {
                return null;
            }
        }


        public DataSet ExcelValidation(string extn, string filePath)
        {
            string conString = string.Empty;
            switch (extn)
            {
                case ".xls": //Excel 97-03.
                    conString = ConfigurationManager.ConnectionStrings["Excel03ConString"].ConnectionString;
                    break;
                case ".xlsx": //Excel 07 and above.
                    conString = ConfigurationManager.ConnectionStrings["Excel07ConString"].ConnectionString;
                    break;

            }

            DataSet ds5 = new DataSet();
            DataSet filterds = new DataSet();
            conString = string.Format(conString, filePath);

            using (OleDbConnection connExcel = new OleDbConnection(conString))
            {
                using (OleDbCommand cmdExcel = new OleDbCommand())
                {
                    using (OleDbDataAdapter odaExcel = new OleDbDataAdapter())
                    {
                        cmdExcel.Connection = connExcel;

                        //Get the name of First Sheet.
                        connExcel.Open();
                        DataTable dtExcelSchema;
                        dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                        string sheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();
                        connExcel.Close();
                        //Read Data from First Sheet.
                        connExcel.Open();
                        cmdExcel.CommandText = "SELECT * From [" + sheetName + "]";
                        odaExcel.SelectCommand = cmdExcel;
                        odaExcel.Fill(ds5);
                        connExcel.Close();

                        DataTable filter = new DataTable();
                        filter.TableName = "FILTERED";
                        filter = ds5.Tables[0];
                        int count = 0;
                        for (int i = filter.Rows.Count - 1; i >= 0; i--)
                        {
                            DataRow dr = filter.Rows[i];

                            if (dr["Requistion ID"].ToString() == "" && dr["Position ID"].ToString() == "")
                            {
                                count++;
                                dr.Delete();
                            }
                        }
                        filter.AcceptChanges();
                        DataTable dtCopy = filter.Copy();
                        filterds.Tables.Add(dtCopy);
                    }
                }
            }
            return filterds;
        }

    }
}