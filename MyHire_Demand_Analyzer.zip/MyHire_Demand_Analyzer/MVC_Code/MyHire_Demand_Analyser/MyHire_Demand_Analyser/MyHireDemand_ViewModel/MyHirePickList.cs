﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyHire_Demand_Analyser.Models;

namespace MyHire_Demand_Analyser.MyHireDemand_ViewModel
{
    public class MyHirePickList
    {
        public IEnumerable<MyHire_PickList_Master> MyHirePick_List { get; set; }
        public IEnumerable<MyHire_PickList_Master> MyHirePick_ORG { get; set; }
        public IEnumerable<MyHire_PickList_Master> MyHirePick_PositionLocationLocation { get; set; }
        public IEnumerable<MyHire_PickList_Master> MyHirePick_ServiceLine { get; set; }
        public IEnumerable<MyHire_PickList_Master> MyHirePick_HiringPU { get; set; }
        public IEnumerable<MyHire_PickList_Master> MyHirePick_Entity { get; set; }
    }
}