﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Collections.Specialized;
using MyHire_Demand_Analyser.MyHireDemand_ViewModel;
using MyHire_Demand_Analyser.Models;
using System.Dynamic;
using System.Web.UI;
using System.IO;
 
namespace MyHire_Demand_Analyser.Controllers
{
    public class PickListMasterController : Controller
    {
        //
        // GET: /PickListMaster/
        MyHire_PickList_Master objMyHirePickMaster = new MyHire_PickList_Master();
        MyHirePickList objMyHirePickList = new MyHirePickList();

        dynamic objPickValue = new ExpandoObject();
               

        public ActionResult PickList()
        {
            try
            {
                return View();
            }
            catch (Exception e)
            {
                ViewBag.Err_Mssg = "Error while Page Loading";
                return View();
            }
        
        }

        [HttpPost]
        public ActionResult PickList(FormCollection rprt)
        {
            try
            {

                //int invaliddate = 0;
                DataTable dtResult = new DataTable();
                string c = rprt["ddlPickList"];

                //if (!string.IsNullOrEmpty(rprt["SD"]))
                //    startDate = Convert.ToDateTime(rprt["SD"], CultureInfo.InvariantCulture);
                //else
                //    startDate = (DateTime)System.Data.SqlTypes.SqlDateTime.MinValue;

                //if (!string.IsNullOrEmpty(rprt["ED"]))
                //    endDate = Convert.ToDateTime(rprt["SD"], CultureInfo.InvariantCulture);
                //else
                //    endDate = (DateTime)System.Data.SqlTypes.SqlDateTime.MinValue;

                //if (Convert.ToDateTime(rprt["SD"], CultureInfo.InvariantCulture) < Convert.ToDateTime(rprt["SD"], CultureInfo.InvariantCulture))
                //{
                //    invaliddate = 1;
                //}

                //if (invaliddate == 0)
                //{
                    if (rprt["ddlPickList"] == "HiringPU")
                    {
                        Response.Write(rprt["ddlPickList"].ToString());
                        string picklistType1 = "HiringPU";
                        dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                        if (dtResult.Rows.Count > 0)
                        {
                            objMyHirePickMaster.ExportPickList(dtResult);
                        }
                        else
                        {
                            ViewBag.Err_Mssg = "No Rejected Records Found";
                        }
                    }

                    if (rprt["ddlPickList"] == "GradeDetails")
                    {
                        Response.Write(rprt["ddlpicklist"].ToString());
                        string picklisttype1 = "gradedetails";

                        dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklisttype1);
                        if (dtResult.Rows.Count > 0)
                        {
                            objMyHirePickMaster.ExportPickList(dtResult);
                        }
                        else
                        {
                            ViewBag.Err_Mssg = "No Rejected Records Found";
                        }
                    }

                    if (rprt["ddlPickList"] == "ServiceLine")
                    {
                        Response.Write(rprt["ddlPickList"].ToString());

                        string picklistType1 = "ServiceLine";


                        dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                        if (dtResult.Rows.Count > 0)
                        {
                            objMyHirePickMaster.ExportPickList(dtResult);
                        }
                        else
                        {
                            ViewBag.Err_Mssg = "No Rejected Records Found";
                        }
                    }
                    if (rprt["ddlPickList"] == "PositionLocation")
                    {
                        Response.Write(rprt["ddlPickList"].ToString());
                        string picklistType1 = "PositionLocationLocation";

                        dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                        if (dtResult.Rows.Count > 0)
                        {
                            objMyHirePickMaster.ExportPickList(dtResult);
                        }
                        else
                        {
                            ViewBag.Err_Mssg = "No Rejected Records Found";
                        }
                    }

                    if (rprt["ddlPickList"] == "MyHireEntity")
                    {
                        Response.Write(rprt["ddlPickList"].ToString());
                        string picklistType1 = "Entity";
                        dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                        if (dtResult.Rows.Count > 0)
                        {
                            objMyHirePickMaster.ExportPickList(dtResult);
                        }
                        else
                        {
                            ViewBag.Err_Mssg = "No Records Found";

                        }
                    }
                    else
                    {
                        ViewBag.Err_Mssg = "Please select PicList value";
                    }
                //}
                //else if (invaliddate > 0)
                //{
                //    ViewBag.Err_Mssg = "Please select PickList Type";
                //}

            }
            catch (Exception ex)
            {
                ViewBag.Err_Mssg = "Retry!!Error Occured";
            }
            return View();
        }

    }
}
