﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Helpers;
using System.IO;
using System.Data;
using System.Data.Entity;
using System.Data.OleDb;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Collections.Specialized;
using MyHire_Demand_Analyser.Models;
using System.Web.UI;
using MyHire_Demand_Analyser.MyHireDemand_ViewModel;
using System.Dynamic;

namespace MyHire_Demand_Analyser.Controllers
{
    public class HomeController : Controller
    {
        MyHire_Demand_Validate objMyHireDemand = new MyHire_Demand_Validate();
        MyHireDemand_Validation objMyHireValid = new MyHireDemand_Validation();
        MyHire_PickList_Master objMyHirePickMaster = new MyHire_PickList_Master();
        MyHirePickList objMyHirePickList = new MyHirePickList();

        static List<MyHire_Demand_Validate> temp = new List<MyHire_Demand_Validate>();

        dynamic objPickValue = new ExpandoObject();
        static List<int> indicate = new List<int>();
        private string positionid;
        public ActionResult Index()
        {

            return View("Index", objMyHireValid);

        }


        [HttpPost]
        public ActionResult Index(HttpPostedFileBase postedFile)
        {
            try
            {

                if (postedFile != null)
                {
                    if (!(postedFile.FileName.EndsWith(".xls") || postedFile.FileName.EndsWith(".xlsx")))
                    {
                        ViewBag.ErrMsg = "Upload .xlsx file only";
                        //indicate = null;
                        return View(objMyHireValid);

                    }
                    else
                    {
                        DataSet dss = new DataSet();
                        DataSet ds = new DataSet();
                        Session["Fileupld"] = postedFile;
                        indicate.Clear();

                        string filePath = string.Empty;
                        string path = Server.MapPath("~/Uploads/");
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }
                        filePath = path + Path.GetFileName(postedFile.FileName);
                        string extension = Path.GetExtension(postedFile.FileName);
                        postedFile.SaveAs(filePath);


                        dss = objMyHireValid.ExcelValidation(extension, filePath);

                        DataTable dt = new DataTable();
                        DataSet ds5 = new DataSet();
                        // ds = objMyHireDemand.GetMyHireDemandDetails(dss);

                        objMyHireValid.MYhireValid = objMyHireDemand.GetMyHireDemandDetail1(dss);//objMyHireDemand.GetMyHireDemandDetail(ds5);
                        temp = objMyHireDemand.GetMyHireDemandDetail1(dss);
                        //string act = "A";
                        ViewBag.B = "active";
                        ViewBag.B1 = "in active";

                        return View(objMyHireValid);

                    }
                }
                else
                {
                    ViewBag.ErrMsg = "Please Select a file first";
                    indicate = null;
                    return View(objMyHireValid);
                }
            }

            catch (Exception ex)
            {

                ViewBag.ErrMsg = "Error While Uploading File.";
                String Message = ex.Message;
                //temp = null;
                //process_valid_obj.process = asp_process_obj.get_details();
                //process_valid_obj.validate = null;

                //return View(process_valid_obj);
                //return(ViewBag);
                return View(objMyHireValid);
            }
        }

        public FileResult MyHire_Template()
        {
            string path = @"~\App_Data\MyHire-Demand_Template.xlsx";
            return File(path, "application/vnd.ms-excel");
        }

        public ActionResult Search(FormCollection position)
        {
            string Positionid1 = position["txtReqid"];

            if (Positionid1 != "" || Positionid1.Length != 0)
            {
                //DataSet ds = new DataSet();
                objMyHireValid.MYhireSingleSearch = objMyHireDemand.Search(Positionid1);
                //objMyHireValid.MYhireValid = objMyHireDemand.Search(Positionid1);//objMyHireDemand.GetMyHireDemandDetail(ds5);    
                temp = objMyHireDemand.Search(Positionid1);
                ViewBag.A = "active";
                ViewBag.A1 = "in active";
                return View("Index", objMyHireValid);
            }
            else
            {
                ViewBag.mesg = "Demand ID can not be blank!";
                ViewBag.chckvalue = "CheckYes";
                return View("Index", objMyHireValid);
            }
        }


        public ActionResult SearchCountrySBU(MyHireDemand_Validation md, FormCollection countrysbu)
        {

            string countrysb = countrysbu["SearchCountrySBU"].ToString();
            string countrysb1 = countrysbu["CountrySBUSearch1"].ToString();
            string countrysb2 = countrysbu["CountrySBUSearch1"].ToString();
            return View();
        }

        [HttpPost]
        public ActionResult PickList(FormCollection rprt)
        {
            try
            {
                DataTable dtResult = new DataTable();
                string c = rprt["ddlPickList"];

                if (c == "HiringPU")
                {
                    Response.Write(rprt["ddlPickList"].ToString());
                    string picklistType1 = "HiringPU";
                    dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                    if (dtResult.Rows.Count > 0)
                    {
                        objMyHirePickMaster.ExportPickList(dtResult);
                    }
                    else
                    {
                        ViewBag.Err_Mssg = "No Rejected Records Found";
                    }
                }

                if (c == "GradeDetails")
                {
                    Response.Write(rprt["ddlpicklist"].ToString());
                    string picklisttype1 = "gradedetails";

                    dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklisttype1);
                    if (dtResult.Rows.Count > 0)
                    {
                        objMyHirePickMaster.ExportPickList(dtResult);
                    }
                    else
                    {
                        ViewBag.Err_Mssg = "No Rejected Records Found";
                    }
                }

                if (c == "ServiceLine")
                {
                    Response.Write(rprt["ddlPickList"].ToString());

                    string picklistType1 = "ServiceLine";


                    dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                    if (dtResult.Rows.Count > 0)
                    {
                        objMyHirePickMaster.ExportPickList(dtResult);
                    }
                    else
                    {
                        ViewBag.Err_Mssg = "No Rejected Records Found";
                    }
                }
                if (c == "PositionLocation")
                {
                    Response.Write(rprt["ddlPickList"].ToString());
                    string picklistType1 = "PositionLocationLocation";

                    dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                    if (dtResult.Rows.Count > 0)
                    {
                        objMyHirePickMaster.ExportPickList(dtResult);
                    }
                    else
                    {
                        ViewBag.Err_Mssg = "No Rejected Records Found";
                    }
                }

                if (c == "MyHireEntity")
                {
                    Response.Write(rprt["ddlPickList"].ToString());
                    string picklistType1 = "Entity";
                    dtResult = objMyHirePickMaster.GetMYhirePickEntity(picklistType1);
                    if (dtResult.Rows.Count > 0)
                    {
                        objMyHirePickMaster.ExportPickList(dtResult);
                    }
                    else
                    {
                        ViewBag.Err_Mssg = "No Records Found";

                    }
                }
                else
                {
                    ViewBag.Err_Mssg = "Please select PicList value";
                }
                //}
                //else if (invaliddate > 0)
                //{
                //    ViewBag.Err_Mssg = "Please select PickList Type";
                //}

            }
            catch (Exception ex)
            {
                ViewBag.Err_Mssg = "Retry!!Error Occured";
            }
            return View();
        }


        public ActionResult ExportInvalid()
        {
            DataTable dtError = new DataTable();
            var grid = new System.Web.UI.WebControls.GridView();
            grid.DataSource = temp;
            grid.DataBind();
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=InvalidASPRecords.xls");
            Response.ContentType = "application/excel";
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            grid.RenderControl(htw);
            Response.Write(sw.ToString());
            Response.End();
            return new EmptyResult();
        }
    }
}
